let coins = 0;

const plots = [];
const crops = ['🌱', '🌱🌱', '🌾'];
let currentWeather = 'Sunny';

document.getElementById("startButton").onclick = () => {
  document.getElementById("startScreen").style.display = "none";
  document.getElementById("gameUI").style.display = "block";
  setupGrid();
};

function setupGrid() {
  const grid = document.getElementById("grid");
  for (let i = 0; i < 6; i++) {
    const plot = document.createElement("div");
    plot.classList.add("plot");
    plot.dataset.index = i;
    plot.innerText = i < 2 ? "🐄" : "🌱🌱";
    plot.onclick = () => harvest(i, plot);
    plots.push({ type: "wheat", stage: 0, element: plot });
    grid.appendChild(plot);
  }
}

function harvest(i, plot) {
  if (plots[i].stage < 2) {
    plots[i].stage++;
    plot.innerText = crops[plots[i].stage];
  } else {
    coins += 10;
    document.getElementById("coinCount").innerText = `💰 Coins: ${coins}`;
    plots[i].stage = 0;
    plot.innerText = crops[0];
  }
}

document.getElementById("shopBtn").onclick = () => {
  toggleMenu("shopMenu");
};
document.getElementById("mapBtn").onclick = () => {
  toggleMenu("mapMenu");
};
document.getElementById("settingsBtn").onclick = () => {
  toggleMenu("settingsMenu");
};

function toggleMenu(menuId) {
  document.querySelectorAll(".sideMenu").forEach(m => {
    m.id === menuId ? m.style.display = m.style.display === "none" ? "block" : "none" : m.style.display = "none";
  });
}

document.getElementById("saveBtn").onclick = () => {
  localStorage.setItem("payDaySave", JSON.stringify({ coins }));
  alert("Game saved!");
};

document.getElementById("resetBtn").onclick = () => {
  localStorage.removeItem("payDaySave");
  location.reload();
};

window.onload = () => {
  const save = localStorage.getItem("payDaySave");
  if (save) {
    coins = JSON.parse(save).coins || 0;
    document.getElementById("coinCount").innerText = `💰 Coins: ${coins}`;
  }
};
